"""CLI package."""
