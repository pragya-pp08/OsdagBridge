"""Pedestal package."""
