"""Girder component package."""
