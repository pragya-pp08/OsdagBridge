"""Deck properties stub."""
